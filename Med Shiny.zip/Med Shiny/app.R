library(tidyverse); library(shiny); library(usmap);


# load data and clean
med_data = read_csv("medicare_data.csv", guess_max = 112000)
real_names = names(med_data)
names(med_data) <- c("DRG", "ID", "Provider", "Address", "City", "state",
                     "Zip", "HRR", "Discharges", "AvgCharge", "AvgTotalPmts", "AvgMedPmts" )

parse2num <- med_data %>% 
  select("AvgCharge":"AvgMedPmts") %>% 
  purrr::map(parse_number) %>% 
  as_tibble()

med_data <- med_data %>% 
  select(-("AvgCharge":"AvgMedPmts")) %>% 
  bind_cols(parse2num)

med_data <- med_data %>% select(-HRR)

med_data <- med_data %>% 
  mutate(TCharge = Discharges * AvgCharge, TotalPmts = Discharges * AvgTotalPmts,
         TMedPmts = Discharges * AvgMedPmts, percent_covered = TMedPmts / TCharge, 
         out_of_pocket = TotalPmts - TMedPmts)






# Shiny App 

ui <- fluidPage(
  titlePanel("US Heat Map of CMS's 2016 Inpatient Data"),
  
  sidebarPanel(
    
      helpText('Creates a heat map of the US based on CMS Inpatient dataset. It summarizes 
               information on services and procedures provided to Medicare benefitiaries by hospitals.
               User can also specify a state to view its value using the state\'s abberviation.',
               br(), br(),
               'Alternatively, the user can  select the "Table" tab to view the values for all states.'),
  
      selectInput("value", h3("Select Value to Display"),
                              choices = list("Average Charge" = "TCharge", "Avg Payment" = "TotalPmts", 
                                             "Average Medicare Payment" = "TMedPmts", 
                                             "Percent Covered by Medicare" = "percent_covered",
                                             "Amount Paid Out of Pocket" = "out_of_pocket"),
                              selected = "Average Charge"),
      
      textInput("state", "Select State (abbr)", 
                value = "TX")
  ),
  
  mainPanel(
    
    tabsetPanel( type = "tabs",
                 tabPanel("Plot", plotOutput("plot"), tableOutput("table")),
                 tabPanel("Table", tableOutput("data"))
      
                )
    
      )
      
  
)


server <- function(input, output){
  
  dataInput <- reactive({
        if(input$value == "percent_covered"){
          med_data %>% 
            group_by(state) %>% 
            summarise(value = sum(TMedPmts) / sum(TCharge))
        } else {
        med_data %>% 
          group_by(state) %>% 
          summarise(value = sum(eval(parse(text = input$value))) / sum(Discharges))
        }
  })
  
  
  output$plot <- renderPlot({
    
    title <- switch(input$value,
                    "TCharge"         = "Average Procedure Charge per State", 
                    "TotalPmts"       = "Average Payment per State", 
                    "TMedPmts"        = "Average Amount Medicare Pays for per State", 
                    "percent_covered" = "Percent Covered by Medicare per State",
                    "out_of_pocket"   = "Average Amount Paid Out of Pocket per State"   
    )
    
    legend <- switch(input$value,
                     "TCharge"         = "Average Charge", 
                     "TotalPmts"       = "Average Payment", 
                     "TMedPmts"        = "Average Medicare Payment", 
                     "percent_covered" = "Percent Covered",
                     "out_of_pocket"   = "Cost"   
    )
    
    
    plot_usmap(data = dataInput(), values = "value", labels = TRUE) +
      scale_fill_continuous(low = "white", high = "red", name = legend) +
      theme(legend.position = "right") +
      labs(title = title)
    
  })
  
  output$table <- renderTable({
    dataInput() %>% filter(state == input$state)
  })
  
  output$data <- renderTable({
    dataInput()
  })
  
  
}


shinyApp(ui, server)